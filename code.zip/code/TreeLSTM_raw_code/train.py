"""
原始Tree-LSTM训练代码(消融实验)
"""
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from torch.optim.lr_scheduler import ReduceLROnPlateau
from sklearn.model_selection import train_test_split
from tqdm import tqdm
import os
import logging
import numpy as np
from datetime import datetime
from datetime import datetime
from torch.utils.tensorboard import SummaryWriter
from sklearn.metrics import accuracy_score, f1_score

# 导入模型
from model import FunctionEmbeddingModel

# 设置环境变量
os.environ["CUDA_VISIBLE_DEVICES"] = "1"

# 创建日志目录
os.makedirs("logs", exist_ok=True)

def setup_logging():
    """配置日志记录器，确保实时输出到文件和终端，并避免重复日志"""
    # 创建或获取日志记录器
    logger = logging.getLogger('training_logger')
    logger.setLevel(logging.INFO)

    # 避免重复添加处理器（防止多次调用时日志重复）
    if logger.handlers:
        logger.handlers.clear()

    # 创建文件处理器（禁用缓冲以确保实时写入）
    log_filename = f"logs/training_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
    file_handler = logging.FileHandler(log_filename, mode='w', encoding='utf-8', delay=False)
    file_handler.setLevel(logging.INFO)

    # 统一格式化器
    formatter = logging.Formatter('%(asctime)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
    file_handler.setFormatter(formatter)

    # 添加处理器
    logger.addHandler(file_handler)

    return logger

# Device
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
logger = setup_logging()

# 数据集类
class FunctionPairDataset(Dataset):
    def __init__(self, pth_file, max_samples=None):
        self.data = torch.load(pth_file)
        if max_samples is not None:
            self.data = self.data[:max_samples]

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        binary1, func1, binary2, func2, ast1, ast2, label = self.data[idx]
        return ast1, ast2, torch.tensor(label, dtype=torch.int64)

# 自定义 collate 函数
def ast_collate_fn(batch):
    ast1_list = []
    ast2_list = []
    label_list = []
    
    for item in batch:
        ast1_list.append(item[0])
        ast2_list.append(item[1])
        label_list.append(item[2])
    
    labels_tensor = torch.stack(label_list)
    
    return ast1_list, ast2_list, labels_tensor

# 训练函数
def train(model, dataloader, optimizer, epoch, writer, margin=1.0):
    logger.info("==================================Training==================================")    
    model.train()
    total_loss = 0.0
    processed_batches = 0
    
    progress_bar = tqdm(enumerate(dataloader), 
                        total=len(dataloader),
                        desc="Training",
                        leave=False)
    
    for batch_idx, (ast1_batch, ast2_batch, labels) in progress_bar:
        logger.info(f"Batch {batch_idx}/{len(progress_bar)}")
        processed_batches += 1
        optimizer.zero_grad()
        
        emb1 = model(ast1_batch)
        emb2 = model(ast2_batch)
        
        cosine_distance = 1 - torch.cosine_similarity(emb1, emb2, dim=1)
        
        labels = labels.to(device)
        loss = labels * torch.pow(cosine_distance, 2) + \
               (1 - labels) * torch.pow(torch.clamp(margin - cosine_distance, min=0.0), 2)
        batch_loss = torch.mean(loss)

        logger.info(f"Batch_loss: {batch_loss:.4f}")

        batch_loss.backward()
        optimizer.step()
        
        total_loss += batch_loss.item()
        progress_bar.set_postfix({'loss': f"{batch_loss.item():.4f}"})
    
    avg_loss = total_loss / processed_batches if processed_batches > 0 else 0
    writer.add_scalar('Train/Loss_epoch', avg_loss, epoch)

    return avg_loss

# 评估函数
def evaluate(model, dataloader, epoch, writer, margin=1.0):
    logger.info("==================================Evaluating==================================") 
    model.eval()
    total_loss = 0.0
    cosine_similarities = []
    labels_list = []
    processed_batches = 0
    
    with torch.no_grad():
        progress_bar = tqdm(dataloader, 
                            total=len(dataloader),
                            desc="Evaluating",
                            leave=False)
        
        for i, (ast1_batch, ast2_batch, labels) in enumerate(progress_bar):
            logger.info(f"Batch {i}/{len(progress_bar)}")
            emb1 = model(ast1_batch)
            emb2 = model(ast2_batch)
            
            cosine_distance = 1 - torch.cosine_similarity(emb1, emb2, dim=1)
            
            labels = labels.to(device)
            loss = labels * torch.pow(cosine_distance, 2) + \
                   (1 - labels) * torch.pow(torch.clamp(margin - cosine_distance, min=0.0), 2)
            batch_loss = torch.mean(loss)
            
            total_loss += batch_loss.item()
            processed_batches += 1

            cosine_sim = torch.cosine_similarity(emb1, emb2, dim=-1)
            cosine_similarities.extend(cosine_sim.cpu().numpy())
            labels_list.extend(labels.cpu().numpy())

            logger.info(f"Batch_loss: {batch_loss.item():.4f}")
            
            progress_bar.set_postfix({
                'loss': f"{batch_loss.item():.4f}",
            })

    avg_loss = total_loss / processed_batches if processed_batches > 0 else 0
    cosine_sim = np.array(cosine_similarities)
    labels_list = np.array(labels_list)
     
    # 预测相似性 (cosine相似度>0.5视为相似)
    preds = (cosine_sim > 0.5).astype(int)
    acc = accuracy_score(labels_list, preds)
    f1 = f1_score(labels_list, preds)
    
    # 记录指标
    writer.add_scalar(f'val/Loss', avg_loss, epoch)
    writer.add_scalar(f'val/Accuracy', acc, epoch)
    writer.add_scalar(f'val/F1_score', f1, epoch)
    
    return avg_loss, {
        'labels': labels,
        'accuracy': acc,
        'f1_score': f1,
    }


# 主函数
def main():
    logger.info(f"==================================Training begin=============================================")
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    writer = SummaryWriter(f'runs/TLSTM-raw_{timestamp}')

    # Hyperparameters
    vocab_size = 81  # Adjust based on your actual vocabulary size
    embedding_dim = 10
    hidden_dim = 16  
    batch_size = 1024  # 充分利用A800显存
    num_epochs = 100   # 减少总epoch数
    learning_rate = 2.4e-3  # 缩放后的学习率

    # Dataset
    pth_file = "/home/liyanlin/HLS/graph/csv/processed_data_with_edges.pth"
    model_dir = "/data/LYL/lyl_bcsd/model-TLSTM-raw/"
    os.makedirs(model_dir, exist_ok=True)

    # Load dataset
    full_dataset = FunctionPairDataset(pth_file)    

    # Split into train and validation
    train_size = int(0.8 * len(full_dataset))
    val_size = len(full_dataset) - train_size
    train_dataset, val_dataset = train_test_split(full_dataset, test_size=val_size, random_state=42)
   
    
    # Create dataloaders
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, collate_fn=ast_collate_fn)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False, collate_fn=ast_collate_fn)

    # Model
    model = FunctionEmbeddingModel(vocab_size, embedding_dim, hidden_dim).to(device)

    # Loss and optimizer
    optimizer = optim.Adam(model.parameters(), lr=learning_rate)
    scheduler = ReduceLROnPlateau(optimizer, mode='min', factor=0.1, patience=3)  # 动态学习率

    progress_bar = tqdm(total=num_epochs, desc="Training Epoch Progress")

    best_val_loss = float('inf')
    best_model_epoch = 0

    # Training loop
    for epoch in range(num_epochs):
        logger.info(f"==================================Epoch {epoch}/{num_epochs}========================================")
        train_loss = train(model, train_loader, optimizer, epoch, writer, margin=1.0)
        val_loss, val_metrics = evaluate(model, val_loader, epoch, writer, margin=1.0)

        logger.info(f"Epoch {epoch:03d} | "
              f"Train Loss: {train_loss:.4f} | "
              f"Val Loss: {val_loss:.4f} | {val_metrics['accuracy']:.4f} | F1: {val_metrics['f1_score']:.4f} | "
              )
        
        scheduler.step(val_loss) 


        if val_loss < best_val_loss:
            best_val_loss = val_loss
            best_model_epoch = epoch 
            torch.save(model.state_dict(), os.path.join(model_dir, f"BEST-TLSTM.pth"))
            logger.info(f"Best model saved")

        progress_bar.update(1)

        torch.save(model.state_dict(), os.path.join(model_dir, f"TLSTM_{epoch}.pth"))

    progress_bar.close()

    logger.info(f"\nFinal model saved.")
    logger.info(f"best_epoch is {best_model_epoch}")
    writer.close()

    logger.info(f"===================================Training end==============================================")

if __name__ == "__main__":
    main()