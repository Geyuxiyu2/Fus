"""
原始Tree-LSTM模型定义文件(消融实验)
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "1"
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

class TreeLSTMCell(nn.Module):
    def __init__(self, input_size, hidden_size):
        super(TreeLSTMCell, self).__init__()
        self.hidden_size = hidden_size
        
        # Gates: input, forget, output, cell
        self.W_iou = nn.Linear(input_size, 3 * hidden_size)
        self.U_iou = nn.Linear(hidden_size, 3 * hidden_size, bias=False)
        
        # Forget gate for children (无边特征)
        self.W_f = nn.Linear(input_size, hidden_size)
        self.U_f = nn.Linear(hidden_size, hidden_size, bias=False)

    def forward(self, x, child_h, child_c):
        """
        原始版本，没有边特征
        Args:
            x: current node feature [1, input_size]
            child_h: stacked children hidden states [num_children, hidden_size]
            child_c: stacked children cell states [num_children, hidden_size]
        """
        child_h = child_h.to(x.device)
        child_c = child_c.to(x.device)

        num_children = child_h.size(0) if child_h.dim() > 1 else 0
        
        # Input/Output/Update gates
        child_h_sum = torch.sum(child_h, dim=0, keepdim=True) if num_children > 0 else torch.zeros(1, self.hidden_size, device=x.device)
        iou = self.W_iou(x) + self.U_iou(child_h_sum)
        i, o, u = torch.split(iou, iou.size(1) // 3, dim=1)
        i, o, u = torch.sigmoid(i), torch.sigmoid(o), torch.tanh(u)
        
        # Forget gates (无边特征)
        if num_children > 0:
            f = self.W_f(x).expand(num_children, -1) + self.U_f(child_h)
            f = torch.sigmoid(f)
        else:
            f = torch.zeros(0, self.hidden_size, device=x.device)  # 无子节点时返回空张量
        
        # Cell state
        if num_children > 0:
            c = i * u + torch.sum(f * child_c, dim=0, keepdim=True)
        else:
            c = i * u  # 叶节点
        
        # Hidden state
        h = o * torch.tanh(c)
        
        return h, c

class TreeLSTM(nn.Module):
    def __init__(self, vocab_size, embedding_dim, hidden_dim):
        super(TreeLSTM, self).__init__()
        self.hidden_dim = hidden_dim
        self.op_embed = nn.Embedding(vocab_size, embedding_dim)  # 仅使用opname嵌入
        self.cell = TreeLSTMCell(embedding_dim, hidden_dim)

    def forward(self, tree):
        # 递归处理子节点
        child_hs, child_cs = [], []
        for child in tree['children']:
            h, c = self.forward(child)
            child_hs.append(h)
            child_cs.append(c)

        if child_hs:
            child_hs = torch.cat(child_hs, dim=0)
            child_cs = torch.cat(child_cs, dim=0)
        else:
            child_hs = torch.zeros(0, self.hidden_dim, device=device)
            child_cs = torch.zeros(0, self.hidden_dim, device=device)

        # 当前节点特征 - 仅opname
        op_idx = tree['op_idx']
        x = self.op_embed(torch.tensor(op_idx, device=device)).unsqueeze(0)

        # Tree-LSTM计算
        h, c = self.cell(x, child_hs, child_cs)

        return h, c

class FunctionEmbeddingModel(nn.Module):
    def __init__(self, vocab_size=81, embedding_dim=10, hidden_dim=16):
        super(FunctionEmbeddingModel, self).__init__()
        self.treelstm = TreeLSTM(vocab_size, embedding_dim, hidden_dim)
        self.proj = nn.Linear(hidden_dim, hidden_dim)
    
    def forward(self, ast_list):
        # 处理一批AST树
        all_embeddings = []
        
        for ast in ast_list:
            # 原始版本使用根节点的隐藏状态作为整个树的表示
            h, _ = self.treelstm(ast)
            embedding = self.proj(h.squeeze(0))  # [hidden_dim]
            all_embeddings.append(embedding.unsqueeze(0))
        
        # 将所有嵌入堆叠成一个张量
        embeddings = torch.cat(all_embeddings, dim=0)  # [batch_size, hidden_dim]
        
        return embeddings