"""
数据预处理
将训练数据集转化为.pth文件
"""
import os
import json
import torch
import pandas as pd
from tqdm import tqdm

# N = 2

opname_to_idx = {
    'idx': 0, 'var': 1, 'entry_ea': 2, 'expr': 3, 'asg': 4,
    'value': 5, 'num': 6, 'block': 7, 'if': 8, 'ptr': 9,
    'cast': 10, 'obj': 11, 'string': 12, 'add': 13, 'return': 14,
    'goto': 15, 'eq': 16, 'lnot': 17, 'ne': 18, 'ref': 19,     
    'sub': 20, 'case': 21, 'call': 22, 'xor': 23, 'band': 24,
    'preinc': 25, 'memptr': 26, 'ult': 27, 'break': 28, 'land': 29,
    'mul': 30, 'asgadd': 31, 'ushr': 32, 'ugt': 33, 'lor': 34,
    'while': 35, 'slt': 36, 'do': 37, 'uge': 38, 'ule': 39,
    'shl': 40, 'bor': 41, 'sge': 42, 'for': 43, 'fnum': 44,
    'sgt': 45, 'memref': 46, 'offset': 47, 'sle': 48, 'switch': 49,
    'postinc': 50, 'udiv': 51, 'empty': 52, 'fmul': 53, 'predec': 54,
    'comma': 55, 'umod': 56, 'asgsub': 57, 'bnot': 58, 'fadd': 59,
    'asgmul': 60, 'asgbor': 61, 'continue': 62, 'asgxor': 63, 'neg': 64,
    'fsub': 65, 'tern': 66, 'sshr': 67, 'asgshl': 68, 'asgband': 69,
    'fdiv': 70, 'helper': 71, 'asgumod': 72, 'asgushr': 73, 'asm': 74,
    'sizeof': 75, 'postdec': 76, 'asgudiv': 77, 'fneg': 78, 'str': 79
}
UNKNOWN_INDEX = 80


def add_op_indices(node):
    """Recursively add op_idx to each node in the AST"""
    if isinstance(node, dict):
        node['op_idx'] = opname_to_idx.get(node['opname'], UNKNOWN_INDEX)
        if 'children' in node:
            for child in node['children']:
                add_op_indices(child)
    return node

def load_ast(binary, func):
    """Load AST from json file and add op indices"""
    binary_path = binary.replace('/', '-')
    ast_path = os.path.join('/data/LYL/lyl_bcsd/dataset/AST/', binary_path, f"{func}.json")
    try:
        with open(ast_path, 'r') as f:
            ast = json.load(f)
            return add_op_indices(ast)
    except FileNotFoundError:
        print(f"AST file not found: {ast_path}")
        return None
    except json.JSONDecodeError:
        print(f"Invalid JSON in: {ast_path}")
        return None

def process_csv_to_pth(csv_path, output_path):
    # Read CSV file, nrows=N
    df = pd.read_csv(csv_path, header=None, names=['binary1', 'func1', 'binary2', 'func2', 'label'])
    
    processed_data = []
    
    # Process each row
    for idx, row in tqdm(df.iterrows(), total=len(df), desc="Processing data"):
        binary1, func1 = row['binary1'], row['func1']
        binary2, func2 = row['binary2'], row['func2']
        label = row['label']
        
        # Load ASTs
        ast1 = load_ast(binary1, func1)
        ast2 = load_ast(binary2, func2)
        
        if ast1 is not None and ast2 is not None:
            processed_data.append([
                binary1,
                func1,
                binary2,
                func2,
                ast1,
                ast2,
                label
            ])
    
    # Save to .pth file
    torch.save(processed_data, output_path)
    print(f"Processed data saved to {output_path}")

if __name__ == "__main__":
    csv_path = "/home/liyanlin/HLS/graph/csv/cross_arch_balanced_20000.csv"
    output_path = "/home/liyanlin/HLS/graph/csv/cross_arch_balanced_20000.pth"
    
    process_csv_to_pth(csv_path, output_path)