import torch
import pickle
import os
import json
import numpy as np
import pandas as pd
from tqdm import tqdm
from model import FunctionEmbeddingModel
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

############################################################################
############################################################################
############################################################################
output_dir = "/data/LYL/lyl_bcsd/dataset/eval/baseline/TreeLSTM-raw"
Model_Path = "/data/LYL/lyl_bcsd/model-TLSTM-raw/BEST-TLSTM.pth"
AST_PATH = "/data/LYL/lyl_bcsd/dataset/eval/Tree-LSTM-raw/"
os.makedirs(output_dir, exist_ok=True)
############################################################################
############################################################################
############################################################################


# 初始化模型（参数需要与训练时一致）
vocab_size = 81
embedding_dim = 10
hidden_dim = 16
model = FunctionEmbeddingModel(vocab_size, embedding_dim, hidden_dim).to(device)

# 加载训练好的权重
model_path = Model_Path
model.load_state_dict(torch.load(model_path, map_location=device))
model.eval()  


def encode_function(binary, func):
    """编码单个函数的AST"""
    binary_path = binary.replace('/', '-')
    ast_path = os.path.join(AST_PATH, binary_path, f"{func}.json")
    try:
        with open(ast_path, 'r') as f:
            ast = json.load(f)
    except Exception as e:
        print(ast_path)
        print(e)
        
    try:
        with torch.no_grad():
            embedding = model([ast])
            emb = embedding.squeeze(0).cpu().numpy()  
            
    except Exception as e:
        print(e)
        emb = None

    file_path = os.path.join(output_dir, binary_path, f"{func}.pkl")
    os.makedirs(os.path.dirname(file_path), exist_ok=True)
    
    if emb is not None:
        if not os.path.exists(file_path):
            save_embedding_to_pkl(emb, file_path)
    else:
        print(f"ERROR emb is None")
    

def save_embedding_to_pkl(embedding, file_path):
    """将嵌入向量保存到pkl文件"""
    with open(file_path, 'wb') as f:
        pickle.dump(embedding, f)
    # print(f"Embedding saved to {file_path}")


def process_csv(csv_path):
    df = pd.read_csv(csv_path, header=None, 
                    names=['binary1', 'func1', 'binary2', 'func2', 'label'])
    
    processed_count = 0
    
    # 处理每一行
    for idx, row in tqdm(df.iterrows(), total=len(df), desc="处理数据"):
        binary1, func1 = row['binary1'], row['func1']
        binary2, func2 = row['binary2'], row['func2']
        
        binary_path_1 = binary1.replace('/', '-')
        file_path_1 = os.path.join(output_dir, binary_path_1, f"{func1}.pkl")
        if not os.path.exists(file_path_1):
            # 处理第一个AST
            ast1 = encode_function(binary1, func1)
        
        binary_path_2 = binary2.replace('/', '-')
        file_path_2 = os.path.join(output_dir, binary_path_2, f"{func2}.pkl")
        if not os.path.exists(file_path_2):
            # 处理第二个AST
            ast2 = encode_function(binary2, func2)
        
        # if ast1 is not None and ast2 is not None:
        #     processed_count += 1
    
    print(f"\n预处理后的文件保存在: {output_dir}")


if __name__ == "__main__":
   
    # csv_dir = "/home/liyanlin/HLS/graph/csv/output-ida"
    
    # print("开始预处理AST数据...")

    # for file in os.listdir(csv_dir):
    #     csv_file = os.path.join(csv_dir, file)
    #     process_csv(csv_file)
    
    # print("预处理完成!")

    process_csv('/home/liyanlin/HLS/graph/csv/vul_csv/vulnerability_ida.csv')

    


