import matplotlib.pyplot as plt

epochs = range(1, 41)
train_loss = [0.2274, 0.1760, 0.1548, 0.1433, 0.1345, 0.1281, 0.1221, 0.1172, 
              0.1139, 0.1112, 0.1079, 0.1046, 0.1018, 0.1005, 0.0976, 0.0954, 
              0.0937, 0.0925, 0.0919, 0.0904, 0.0889, 0.0871, 0.0867, 0.0867, 
              0.0854, 0.0843, 0.0837, 0.0834, 0.0827, 0.0817, 0.0815, 0.0802, 
              0.0800, 0.0791, 0.0787, 0.0775, 0.0770, 0.0763, 0.0763, 0.0752]

plt.figure(figsize=(10, 5))
plt.plot(epochs, train_loss, 'b-', label='Train Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.title('Training Loss Curve')
plt.legend()
plt.grid()
plt.savefig('training_loss_curve.png', 
            dpi=300, 
            bbox_inches='tight', 
            facecolor='white')