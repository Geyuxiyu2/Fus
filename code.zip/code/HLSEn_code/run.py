"""
使用训练好的SiameseCodeBERT模型对二进制函数代码生成嵌入向量
优化版本：增强可读性、错误处理和类型安全
"""
import os
import pickle
from pathlib import Path
from typing import Optional, Tuple, List, Dict
import numpy as np
import torch
from tqdm import tqdm
from transformers import AutoTokenizer

os.environ["CUDA_VISIBLE_DEVICES"] = "0,1,2,3"
from utils.model import Config, SiameseCodeBERT


class CodeEmbeddingGenerator:
    def __init__(self, model_path: str, decompile_dir: str, device: str = "cuda"):
        """
        初始化嵌入生成器
        Args:
            model_path: 模型检查点路径
            decompile_dir: 反编译代码存放目录
            device: 计算设备
        """
        self.device = device
        self.decompile_dir = Path(decompile_dir)
        
        # 加载模型和配置
        self.model, self.tokenizer, self.config = self._load_model(model_path)
        self.model.eval()
        
    @staticmethod
    def _load_model(model_path: str) -> Tuple[SiameseCodeBERT, AutoTokenizer, Config]:
        """加载训练好的模型和tokenizer"""
        checkpoint = torch.load(model_path, map_location='cpu', weights_only=False)
        
        config = checkpoint['config']
        tokenizer = AutoTokenizer.from_pretrained(config.model_path)
        
        model = SiameseCodeBERT(config.model_path).to(config.device)
        model.load_state_dict(checkpoint['model_state_dict'])
        
        return model, tokenizer, config

    def _read_code(self, binary: str, func: str) -> Optional[str]:
        """读取反编译的C代码"""
        code_path = self.decompile_dir / binary.replace('/', '-') / f"{func}.c"
        try:
            with open(code_path, 'r', encoding='utf-8', errors='ignore') as f:
                return f.read()
        except FileNotFoundError:
            print(f"[WARNING] Code not found: {code_path}")
            return None

    def get_embedding(self, binary: str, func: str) -> Optional[np.ndarray]:
        """
        生成单个函数的代码嵌入
        Args:
            binary: 二进制文件名
            func: 函数名
        Returns:
            numpy数组形式的嵌入向量，若失败返回None
        """
        code = self._read_code(binary, func)
        if not code:
            return None

        try:
            inputs = self.tokenizer(
                code,
                max_length=self.config.max_length,
                padding="max_length",
                truncation=True,
                return_tensors="pt"
            ).to(self.device)
            
            with torch.no_grad():
                outputs = self.model.codebert(
                    inputs["input_ids"], 
                    attention_mask=inputs["attention_mask"]
                )
                return outputs.last_hidden_state[:, 0, :].cpu().numpy()
        except Exception as e:
            print(f"[ERROR] Failed to process {binary}/{func}: {str(e)}")
            return None

    @staticmethod
    def save_embedding(embedding: np.ndarray, save_path: str) -> bool:
        """保存嵌入向量到文件"""
        try:
            os.makedirs(os.path.dirname(save_path), exist_ok=True)
            with open(save_path, 'wb') as f:
                pickle.dump(embedding, f)
            return True
        except Exception as e:
            print(f"[ERROR] Failed to save {save_path}: {str(e)}")
            return False

    def process_csv(self, csv_path: str, output_dir: str) -> Dict[str, int]:
        """
        处理CSV文件中的函数对
        Args:
            csv_path: 输入CSV路径
            output_dir: 输出目录
        Returns:
            统计字典 {'processed': 成功处理数, 'skipped': 跳过数, 'failed': 失败数}
        """
        stats = {'processed': 0, 'skipped': 0, 'failed': 0}
        output_dir = Path(output_dir)
        
        with open(csv_path, 'r') as f:
            lines = [line.strip().split(',') for line in f if line.strip()]
        
        print(f"Processing {len(lines)} function pairs from {csv_path}")
        
        for items in tqdm(lines, desc=f"Processing {csv_path}"):
            if len(items) != 5:  # 格式校验
                stats['failed'] += 1
                continue
                
            bin1, func1, bin2, func2, _ = items
            emb_path1 = output_dir / bin1.replace("/", "-") / f"{func1}.pkl"
            emb_path2 = output_dir / bin2.replace("/", "-") / f"{func2}.pkl"
            
            # 处理第一个函数
            if not emb_path1.exists():
                emb1 = self.get_embedding(bin1, func1)
                if emb1 is not None:
                    if self.save_embedding(emb1, str(emb_path1)):
                        stats['processed'] += 1
                    else:
                        stats['failed'] += 1
                else:
                    stats['failed'] += 1
            
            # 处理第二个函数
            if not emb_path2.exists():
                emb2 = self.get_embedding(bin2, func2)
                if emb2 is not None:
                    if self.save_embedding(emb2, str(emb_path2)):
                        stats['processed'] += 1
                    else:
                        stats['failed'] += 1
                else:
                    stats['failed'] += 1
            
            stats['skipped'] += (emb_path1.exists() + emb_path2.exists())
        
        return stats


if __name__ == "__main__":
    # 配置路径
    MODEL_PATH = "/data/LYL/lyl_bcsd/model-HLS/code_bert_train-2025-7-14.pt_40.pt"
    DECOMPILE_DIR = "/data/LYL/lyl_bcsd/dataset/eval/c_code"
    OUTPUT_DIR = "/data/LYL/lyl_bcsd/dataset/eval/baseline/HLS"
    CSV_DIR = "/home/liyanlin/HLS/graph/csv/output-ida"

    # 初始化生成器
    generator = CodeEmbeddingGenerator(
        model_path=MODEL_PATH,
        decompile_dir=DECOMPILE_DIR
    )

    # 确保输出目录存在
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # # 处理所有CSV文件
    # total_stats = {'processed': 0, 'skipped': 0, 'failed': 0}
    # for csv_file in os.listdir(CSV_DIR):
    #     if csv_file.endswith('.csv'):
    #         stats = generator.process_csv(
    #             os.path.join(CSV_DIR, csv_file),
    #             OUTPUT_DIR
    #         )
    #         for k in total_stats:
    #             total_stats[k] += stats[k]
    
    # print("\nFinal Statistics:")
    # print(f"- Processed: {total_stats['processed']} functions")
    # print(f"- Skipped (already exists): {total_stats['skipped']}")
    # print(f"- Failed: {total_stats['failed']}")

    path = '/home/liyanlin/HLS/graph/csv/vul_csv/vulnerability_ida.csv'
    generator.process_csv(
                path,
                OUTPUT_DIR
            )