"""
模型参数配置
"""
import torch
import torch.nn as nn
import pandas as pd
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "2"
from torch.utils.data import Dataset
from transformers import AutoModel, AutoTokenizer


# 1. 配置参数
class Config:
    def __init__(self):
        # 使用本地CodeBERT路径
        self.model_path = "/data/LYL/lyl_bcsd/model/codebert-base/"
        self.model_name = "HLS"
        self.max_length = 512  # 增加长度以适应可能的更长伪代码
        self.batch_size = 16
        self.learning_rate = 5e-5
        self.epochs = 100
        self.margin = 1.0  # 对比损失的边界
        self.patience = 3
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.save_path = "/data/LYL/lyl_bcsd/model-HLS/code_bert_train-2025-7-14.pt_best.pt"
        os.makedirs(os.path.dirname(self.save_path), exist_ok=True)
        # self.best_save_path = "/data/LYL/lyl_bcsd/model-HLS/code_bert_train-2025-7-14.pt_best.pt"
        
        # 数据集路径
        self.train_csv_path = "/home/liyanlin/HLS/graph/csv/cross_opt_balanced_20000_same_arch.csv"
        self.decompile_base_path = "/data/LYL/lyl_bcsd/dataset/eval/c_code"

config = Config()

# 2. 数据加载和预处理
class PseudoCodeDataset(Dataset):
    def __init__(self, df: pd.DataFrame, tokenizer, max_length):
        self.df = df
        self.tokenizer = tokenizer
        self.max_length = max_length
    
    def __len__(self):
        return len(self.df)
    
    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        
        def read_pseudo_code(binary, func):
            file_path = os.path.join(
                config.decompile_base_path, 
                binary.replace('/','-'), 
                f"{func}.c"
            )
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    return f.read()
            except Exception as e:
                print(f"Error reading file: {file_path} - {str(e)}")
                return None
        
        code1 = read_pseudo_code(row[0], row[1])
        code2 = read_pseudo_code(row[2], row[3])
       
        if code1 is None or code2 is None:
            return {
                "input_ids1": torch.zeros(self.max_length, dtype=torch.long),
                "attention_mask1": torch.zeros(self.max_length, dtype=torch.long),
                "input_ids2": torch.zeros(self.max_length, dtype=torch.long),
                "attention_mask2": torch.zeros(self.max_length, dtype=torch.long),
                "label": torch.tensor(-1, dtype=torch.float) 
            }
      
        inputs1 = self.tokenizer(
            code1,
            max_length=self.max_length,
            padding="max_length",
            truncation=True,
            return_tensors="pt"
        )
        
        inputs2 = self.tokenizer(
            code2,
            max_length=self.max_length,
            padding="max_length",
            truncation=True,
            return_tensors="pt"
        )
        
        label = row[4]  
        
        return {
            "input_ids1": inputs1["input_ids"].squeeze(0),
            "attention_mask1": inputs1["attention_mask"].squeeze(0),
            "input_ids2": inputs2["input_ids"].squeeze(0),
            "attention_mask2": inputs2["attention_mask"].squeeze(0),
            "label": torch.tensor(label, dtype=torch.float)
        }
    
    
# 3. 模型定义
class SiameseCodeBERT(nn.Module):
    def __init__(self, model_path):
        super(SiameseCodeBERT, self).__init__()
        self.codebert = AutoModel.from_pretrained(model_path)
        self.dropout = nn.Dropout(p=0.2)
        
    def forward(self, input_ids1, attention_mask1, input_ids2, attention_mask2):
        outputs1 = self.codebert(input_ids1, attention_mask=attention_mask1)
        embedding1 = outputs1.last_hidden_state[:, 0, :]  
        embedding1 = self.dropout(embedding1)
        
        outputs2 = self.codebert(input_ids2, attention_mask=attention_mask2)
        embedding2 = outputs2.last_hidden_state[:, 0, :]
        embedding2 = self.dropout(embedding2)
        
        return embedding1, embedding2

# 4. 对比损失函数
class ContrastiveLoss(nn.Module):
    def __init__(self, margin=1.0):
        super(ContrastiveLoss, self).__init__()
        self.margin = margin
        
    def forward(self, embedding1, embedding2, label):
        cosine_distance = 1 - torch.cosine_similarity(embedding1, embedding2)
        loss = torch.mean((label) * torch.pow(cosine_distance, 2) +
            (1-label) * torch.pow(torch.clamp(self.margin - cosine_distance, min=0.0), 2))
        return loss