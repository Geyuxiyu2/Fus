"""
改进后的模型训练脚本
"""
import torch
from transformers import AutoModel, AutoTokenizer
from torch.utils.data import DataLoader, random_split
from torch.utils.tensorboard import SummaryWriter
import pandas as pd
import numpy as np
from tqdm import tqdm  
from utils.model import Config, PseudoCodeDataset, SiameseCodeBERT, ContrastiveLoss
import os
from datetime import datetime
from sklearn.metrics import accuracy_score, f1_score
from torch.utils.data import Subset
import logging
from datetime import datetime

# 设置GPU
os.environ["CUDA_VISIBLE_DEVICES"] = "2"
# 创建日志目录
os.makedirs("logs", exist_ok=True)

def setup_logging():
    """配置日志记录器，确保实时输出到文件和终端，并避免重复日志"""
    # 创建或获取日志记录器
    logger = logging.getLogger('training_logger')
    logger.setLevel(logging.INFO)

    # 避免重复添加处理器（防止多次调用时日志重复）
    if logger.handlers:
        logger.handlers.clear()

    # 创建文件处理器（禁用缓冲以确保实时写入）
    log_filename = f"logs/training_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
    file_handler = logging.FileHandler(log_filename, mode='w', encoding='utf-8', delay=False)
    file_handler.setLevel(logging.INFO)

    # 统一格式化器
    formatter = logging.Formatter('%(asctime)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
    file_handler.setFormatter(formatter)

    # 添加处理器
    logger.addHandler(file_handler)

    return logger

logger = setup_logging()

config = Config()

def collate_fn(batch):
    batch = [b for b in batch if b['label'] != -1]
    
    if len(batch) == 0:
        return None
    
    elem = batch[0]
    collated = {}
    
    for key in elem:
        if isinstance(elem[key], torch.Tensor):
            collated[key] = torch.stack([d[key] for d in batch])
        else:
            collated[key] = [d[key] for d in batch]
    
    return collated

def train(model, dataloader, optimizer, criterion, device, epoch, writer):
    logger.info("==================================Training==================================")    
    model.train()
    total_loss = 0
    processed_batches = 0

    progress_bar = tqdm(enumerate(dataloader), 
                        total=len(dataloader),
                        desc=f"Training Epoch {epoch}",
                        leave=True)
    
    for batch_idx, batch in progress_bar:
        if batch is None:  
            continue
        
        logger.info(f"Batch {batch_idx}/{len(progress_bar)}")

        input_ids1 = batch["input_ids1"].to(device)
        attention_mask1 = batch["attention_mask1"].to(device)
        input_ids2 = batch["input_ids2"].to(device)
        attention_mask2 = batch["attention_mask2"].to(device)
        labels = batch["label"].to(device)
        
        optimizer.zero_grad()
        embedding1, embedding2 = model(input_ids1, attention_mask1, input_ids2, attention_mask2)
        loss = criterion(embedding1, embedding2, labels)
        
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)  # 梯度裁剪
        optimizer.step()
        
        total_loss += loss.item()
        processed_batches += 1
      
        current_lr = optimizer.param_groups[0]['lr']
        progress_bar.set_postfix({
            'loss': f"{loss.item():.4f}",
            'lr': f"{current_lr:.2e}"
        })
        logger.info(f"Batch_loss: {loss.item():.4f}")
    avg_loss = total_loss / processed_batches if processed_batches > 0 else 0
    writer.add_scalar('Train/Loss_epoch', avg_loss, epoch)
    return avg_loss

def evaluate(model, dataloader, criterion, device, epoch, writer, phase='val'):
    logger.info("==================================Evaluating==================================") 
    model.eval()
    total_loss = 0
    cosine_similarities = []
    labels = []
    processed_batches = 0
    
    progress_bar = tqdm(dataloader, 
                       desc=f"Evaluating {phase} Epoch {epoch}",
                       leave=True)
    
    with torch.no_grad():
        for i, batch in enumerate(progress_bar):
            if batch is None:
                continue

            logger.info(f"Batch {i}/{len(progress_bar)}")

            input_ids1 = batch["input_ids1"].to(device)
            attention_mask1 = batch["attention_mask1"].to(device)
            input_ids2 = batch["input_ids2"].to(device)
            attention_mask2 = batch["attention_mask2"].to(device)
            batch_labels = batch["label"].to(device)
            
            embedding1, embedding2 = model(input_ids1, attention_mask1, input_ids2, attention_mask2)
            
            loss = criterion(embedding1, embedding2, batch_labels)
            total_loss += loss.item()
            processed_batches += 1
            
            cosine_sim = torch.cosine_similarity(embedding1, embedding2, dim=1)
            cosine_similarities.extend(cosine_sim.cpu().numpy())
            labels.extend(batch_labels.cpu().numpy())

            logger.info(f"Batch_loss: {loss.item():.4f}")
    
    avg_loss = total_loss / processed_batches if processed_batches > 0 else 0
    cosine_sim = np.array(cosine_similarities)
    labels = np.array(labels)
    
    
    # 预测相似性 (cosine相似度>0.5视为相似)
    preds = (cosine_sim > 0.5).astype(int)
    acc = accuracy_score(labels, preds)
    f1 = f1_score(labels, preds)
    
    # 记录指标
    writer.add_scalar(f'{phase}/Loss', avg_loss, epoch)
    writer.add_scalar(f'{phase}/Accuracy', acc, epoch)
    writer.add_scalar(f'{phase}/F1_score', f1, epoch)
    
    return avg_loss, {
        'labels': labels,
        'accuracy': acc,
        'f1_score': f1,
    }

def main():
    # 设置TensorBoard
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    writer = SummaryWriter(f'runs/{config.model_name}_{timestamp}')
    
    # 加载数据
    train_df = pd.read_csv(config.train_csv_path, header=None)
    print(f"Loaded {len(train_df)} training samples")
    
    # 划分训练集和验证集 (80%训练，20%验证)
    train_size = int(0.8 * len(train_df))
    val_size = len(train_df) - train_size
    train_dataset, val_dataset = random_split(
        PseudoCodeDataset(train_df, AutoTokenizer.from_pretrained(config.model_path), config.max_length),
        [train_size, val_size]
    )
    
    tokenizer = AutoTokenizer.from_pretrained(config.model_path)
    model = SiameseCodeBERT(config.model_path).to(config.device)
    
    # train_subset = Subset(train_dataset, indices=range(10))
    # val_subset = Subset(val_dataset, indices=range(10))

    # 数据加载器
    train_dataloader = DataLoader(
        train_dataset, 
        # train_subset,
        batch_size=config.batch_size, 
        shuffle=True,
        collate_fn=collate_fn,
        num_workers=4,
        pin_memory=True
    )
    
    val_dataloader = DataLoader(
        val_dataset,
        # val_subset,
        batch_size=config.batch_size,
        shuffle=False,
        collate_fn=collate_fn,
        num_workers=4,
        pin_memory=True
    )
    
    # 优化器和损失函数
    optimizer = torch.optim.AdamW(model.parameters(), lr=config.learning_rate, weight_decay=1e-4)
    criterion = ContrastiveLoss(margin=config.margin)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, 
        mode='min', 
        factor=0.3,  # 更激进的学习率衰减
        patience=1,  # 更早触发衰减
        min_lr=1e-6,  # 设置最小学习率
        verbose=True
    )
    
    # 训练循环
    best_val_loss = float('inf')

    best_model_epoch = 0

    logger.info(f"==================================Training begin=============================================")
    for epoch in range(config.epochs):
        logger.info(f"==================================Epoch {epoch}/{config.epochs}========================================")
        
        # 训练阶段
        train_loss = train(model, train_dataloader, optimizer, criterion, config.device, epoch, writer)
        print(f"Train Loss: {train_loss:.4f}")
        
        # 验证阶段
        val_loss, val_metrics = evaluate(model, val_dataloader, criterion, config.device, epoch, writer, 'val')
        

        logger.info(f"Epoch {epoch:03d} | "
              f"Train Loss: {train_loss:.4f} | "
              f"Val Loss: {val_loss:.4f} | {val_metrics['accuracy']:.4f} | F1: {val_metrics['f1_score']:.4f} | "
              )
               
        # 学习率调度
        scheduler.step(val_loss)
        
        # 模型保存
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            best_model_epoch = epoch 
            # 保存最佳模型
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'loss': val_loss,
                'metrics': val_metrics,
                'config': config
            }, f"{config.save_path}_best.pt")
            # print(f"Best model saved with val loss: {val_loss:.4f}")
    
    
        torch.save({
            'epoch': epoch,
            'model_state_dict': model.state_dict(),
            'optimizer_state_dict': optimizer.state_dict(),
            'loss': val_loss,
            'metrics': val_metrics,
            'config': config
        }, f"{config.save_path}_{epoch}.pt")
        
    logger.info(f"\nFinal model saved to {config.save_path}")
    logger.info(f"best_epoch is {best_model_epoch}")
    writer.close()

if __name__ == "__main__":
    main()