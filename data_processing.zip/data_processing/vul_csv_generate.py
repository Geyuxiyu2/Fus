import csv
import itertools
import os

# 定义漏洞信息
vulnerabilities = [
    {"cve": "CVE-2023-42366", "version": "1.36.1", "func": "next_token()"},
    {"cve": "CVE-2023-42365", "version": "1.36.1", "func": "copyvar()"},
    {"cve": "CVE-2023-42363", "version": "1.36.1", "func": "xasprintf()"},
    {"cve": "CVE-2021-42386", "version": "1.34.0", "func": "nvalloc()"},
    {"cve": "CVE-2021-42385", "version": "1.34.0", "func": "evaluate()"},
    {"cve": "CVE-2021-42384", "version": "1.34.0", "func": "handle_special()"},
    {"cve": "CVE-2021-42382", "version": "1.34.0", "func": "getvar_s()"},
    {"cve": "CVE-2021-42381", "version": "1.34.0", "func": "hash_init()"},
    {"cve": "CVE-2021-42380", "version": "1.34.0", "func": "clrvar()"},
    {"cve": "CVE-2021-42379", "version": "1.34.0", "func": "next_input_file()"},
    {"cve": "CVE-2021-42378", "version": "1.34.0", "func": "getvar_i()"}
]

base_dir = "/data/LYL/lyl_bcsd/dataset/vul/"
# 定义变体选项
arch_options = ["arm", "x86_64"]
opt_options = ["O0", "O1", "O2", "O3", "Os"]

# 生成所有变体组合
def generate_variants(version):
    variants = []
    for arch in arch_options:
        for opt in opt_options:
            variants.append(f"busybox_{version}_{arch}_{opt}")
    return variants

# 生成函数对
pairs = []
for vuln in vulnerabilities:
    version = vuln["version"].replace(".", "_")
    func = vuln["func"]
    variants = generate_variants(version)
    
    
    # all_combinations = list(itertools.combinations(variants, 2))
    # # selected_combinations = all_combinations[:5]  # 取前5组
    
    for i in range(0, len(variants) - 1, 2):
        binary1 = variants[i]
        binary2 = variants[i + 1] 
        binary1_path = os.path.join(base_dir, f"busybox_{version}", binary1)
        binary2_path = os.path.join(base_dir, f"busybox_{version}", binary2) 
        pairs.append({
            "binary1": binary1_path,
            "func1": func,
            "binary2": binary2_path,
            "func2": func,
            "label": 1
        })

# 写入CSV文件
with open("vulnerability_pairs.csv", "w", newline="") as csvfile:
    fieldnames = ["binary1", "func1", "binary2", "func2", "label"]
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    
    writer.writeheader()
    for pair in pairs:
        writer.writerow(pair)

print("CSV文件已生成，共55组函数对。")