"""
数据预处理
预先计算opname对应的数字、边类型、节点深度、子树节点大小、操作类型权重
把数据保存成.pth文件
"""

import os
import json
import torch
import pandas as pd
from tqdm import tqdm
from collections import defaultdict

# 操作符到索引的映射
opname_to_idx = {
    'idx': 0, 'var': 1, 'entry_ea': 2, 'expr': 3, 'asg': 4,
    'value': 5, 'num': 6, 'block': 7, 'if': 8, 'ptr': 9,
    'cast': 10, 'obj': 11, 'string': 12, 'add': 13, 'return': 14,
    'goto': 15, 'eq': 16, 'lnot': 17, 'ne': 18, 'ref': 19,     
    'sub': 20, 'case': 21, 'call': 22, 'xor': 23, 'band': 24,
    'preinc': 25, 'memptr': 26, 'ult': 27, 'break': 28, 'land': 29,
    'mul': 30, 'asgadd': 31, 'ushr': 32, 'ugt': 33, 'lor': 34,
    'while': 35, 'slt': 36, 'do': 37, 'uge': 38, 'ule': 39,
    'shl': 40, 'bor': 41, 'sge': 42, 'for': 43, 'fnum': 44,
    'sgt': 45, 'memref': 46, 'offset': 47, 'sle': 48, 'switch': 49,
    'postinc': 50, 'udiv': 51, 'empty': 52, 'fmul': 53, 'predec': 54,
    'comma': 55, 'umod': 56, 'asgsub': 57, 'bnot': 58, 'fadd': 59,
    'asgmul': 60, 'asgbor': 61, 'continue': 62, 'asgxor': 63, 'neg': 64,
    'fsub': 65, 'tern': 66, 'sshr': 67, 'asgshl': 68, 'asgband': 69,
    'fdiv': 70, 'helper': 71, 'asgumod': 72, 'asgushr': 73, 'asm': 74,
    'sizeof': 75, 'postdec': 76, 'asgudiv': 77, 'fneg': 78, 'str': 79
}
UNKNOWN_INDEX = 80

# 操作符权重
def init_op_weights():
    weights = defaultdict(lambda: 1.0)  # 默认权重1.0
    
    # 关键操作 (1.5)
    key_ops = ['call', 'ptr', 'cast', 'if', 'for', 'goto', 'while', 'do', 
             'switch', 'return', 'break', 'continue', 'memptr', 'memref', 'ref']
    for op in key_ops:
        weights[op] = 1.5
    
    # 重要操作 (1.3)
    important_ops = ['asg', 'preinc', 'postinc', 'predec', 'postdec', 
                    'asgadd', 'asgsub', 'asgmul', 'asgbor', 'asgxor']
    for op in important_ops:
        weights[op] = 1.3
        
    return weights

op_weights = init_op_weights()

def get_edge_type(parent_opname, child_opname):
    """根据父节点和子节点的操作符名称返回边类型"""
    control_flow_parents = {
        'if', 'while', 'for', 'do', 'switch', 'goto',
        'break', 'continue', 'case', 'return', 'tern'
    }
    control_flow_children = {'block', 'case'}  
    arithmetic_ops = {
        'add', 'sub', 'mul', 'div', 'mod', 'eq', 'ne',
        'lt', 'gt', 'le', 'ge', 'and', 'or', 'xor', 'lnot',
        'land', 'lor', 'band', 'bor', 'bnot', 'ushr', 'shl',
        'ult', 'ugt', 'ule', 'uge', 'slt', 'sgt', 'sle', 'sge'
    }
    memory_ops = {
        'ptr', 'ref', 'memptr', 'memref', 'idx', 'offset',
        'sizeof', 'cast'
    }
    
    if parent_opname in control_flow_parents:
        if parent_opname in {'if', 'while', 'for', 'tern'} and \
        child_opname in arithmetic_ops.union({'var', 'num', 'fnum'}):
            return 2
        if child_opname in control_flow_children:
            return 1
        if parent_opname == 'case':
            return 1
        return 0
    
    if parent_opname == 'call':
        return 2
    
    if parent_opname.startswith('asg'):
        return 2
    
    if parent_opname in arithmetic_ops or child_opname in arithmetic_ops:
        return 2
    
    if parent_opname in memory_ops or child_opname in memory_ops:
        return 2
    
    return 0

def calculate_tree_metrics(node, depth=0):
    """递归计算树的指标并增强节点数据"""
    subtree_size = 1
    children_with_metrics = []
    edge_types = []
    
    for child in node.get('children', []):
        child_with_metrics, child_size = calculate_tree_metrics(child, depth + 1)
        children_with_metrics.append(child_with_metrics)
        edge_types.append(get_edge_type(node['opname'], child['opname']))
        subtree_size += child_size
    
    enhanced_node = {
        'opname': node['opname'],
        'op_idx': opname_to_idx.get(node['opname'], UNKNOWN_INDEX),
        'depth': depth,
        'subtree_size': subtree_size,
        'weight': op_weights[node['opname']],
        'edge_types': edge_types,
        'children': children_with_metrics
    }
    
    # 保留原始节点中的其他属性
    for key, value in node.items():
        if key not in ['opname', 'children']:
            enhanced_node[key] = value
    
    return enhanced_node, subtree_size

def load_and_preprocess_ast(binary, func_name):
    """加载并预处理单个AST"""
    ast_path = os.path.join('/data/LYL/lyl_bcsd/dataset/AST/', binary.replace('/', '-'), f"{func_name}.json")
    try:
        with open(ast_path, 'r') as f:
            ast = json.load(f)
        enhanced_ast, _ = calculate_tree_metrics(ast)
        return enhanced_ast
    except Exception as e:
        print(f"Error processing {ast_path}: {str(e)}")
        return None

def preprocess_csv_to_pth(csv_file, output_pth_file):
    """直接从CSV文件预处理并保存为.pth文件"""
    # 读取CSV文件
    df = pd.read_csv(csv_file, header=None,
                    names=['binary1', 'func1', 'binary2', 'func2', 'label'])
    
    processed_pairs = []
    
    # 处理每一对函数
    for _, row in tqdm(df.iterrows(), total=len(df), desc="Processing pairs"):
        # 处理第一个AST
        ast1 = load_and_preprocess_ast(row['binary1'], row['func1'])
        if ast1 is None:
            continue
        
        # 处理第二个AST
        ast2 = load_and_preprocess_ast(row['binary2'], row['func2'])
        if ast2 is None:
            continue
        
        # 添加到结果列表
        processed_pairs.append((row['binary1'], row['func1'], row['binary2'], row['func2'], ast1, ast2, int(row['label'])))
    
    # 保存为.pth文件
    torch.save(processed_pairs, output_pth_file)
    print(f"\nSuccessfully processed {len(processed_pairs)} pairs. Saved to {output_pth_file}")

if __name__ == "__main__":
    # 输入CSV文件路径
    csv_file = "/home/liyanlin/HLS/graph/csv/cross_arch_balanced_20000.csv"
    # 输出.pth文件路径
    output_pth_file = "/home/liyanlin/HLS/graph/csv/processed_data_with_edges.pth"
    
    print("Starting preprocessing...")
    preprocess_csv_to_pth(csv_file, output_pth_file)
    print("Preprocessing completed!")