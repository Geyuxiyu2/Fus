"""
生成抽象语法树
"""
import subprocess

IDA_PATH = "/home/liyanlin/ida-pro-9.0/idat"
Script = "/home/liyanlin/HLS/graph/csv/AST_script.py"
TimeOut = 360

def extract_function_ast(binary_path, func_name=""): # the described function 2
    compilation_list = ['O0', 'O1', 'O2', 'O3']
    opt = "default"
    for compilation in compilation_list:
        if compilation in binary_path:
            opt = compilation
        else:
            continue
    
    com_list = ['clang', 'gcc']
    com_1 = 'gcc'
    for com in com_list:
        if com in binary_path:
            com_1 = com 

    IDA_ARGS = ["-o %s" % opt,  "-g %s" % com_1]

    if func_name:
        IDA_ARGS.append("-f %s" % func_name)
    IDA_ARGS = " ".join(IDA_ARGS)

    Header = "TVHEADLESS=1"
    cmd_list = [Header, IDA_PATH, "-c" ,"-A", '-S"%s %s"' % (Script, IDA_ARGS), binary_path]
    cmd = " ".join(cmd_list)
    p = subprocess.Popen(cmd, shell =True)
    try:
        p.wait(timeout=TimeOut) # after waiting , kill the subprocess
    except subprocess.TimeoutExpired as e:
        print("[Error] time out for %s" % binary_path)
    if p.returncode != 0:
        print("[ERROR] cmd: %s" %(cmd))
        if p:
            p.kill()
    else:

        print("[OK] cmd %s " % cmd)


# ===============================for test============================================
binary_path_1 ="/home/liyanlin/HLS/tst/binary/cpio-2.12_clang-5.0_arm_64_O1_cpio.elf"

binary_path_2 ="/home/liyanlin/HLS/tst/binary/cpio-2.12_clang-5.0_mipseb_64_O1_cpio.elf"

func_name = "until_short"
# binary_path = "/home/liyanlin/HLS/graph/1"
extract_function_ast(binary_path_1, func_name=func_name)

extract_function_ast(binary_path_2, func_name=func_name)

