#encoding=utf-8
"""
Python3
IDAPython script running with Hexray plugin !!!
usage: /home/liyanlin/ida-pro-9.0/idat -A -c -Lida.log -SAST_script.py /data/LYL/lyl_bcsd/dataset/trex/arm-32/binutils-2.30-O0/bfdtest1
Extracting the asts of all functions in the binary file and save the function information along with ast to the database file
"""
# txt_root="/data/LYL/lyl_bcsd/dataset/eval/AST"
# c_code_root="/data/LYL/lyl_bcsd/dataset/eval/c_code"
# asm_code_root="/data/LYL/lyl_bcsd/dataset/eval/asm_code"  # 新增汇编代码保存路径

txt_root="/home/liyanlin/HLS/tst/AST"
c_code_root="/home/liyanlin/HLS/tst/c_code"
asm_code_root="/home/liyanlin/HLS/tst/asm_code" 

import idautils
import idaapi
from idc import *
from idaapi import *
from idautils import *
import os,sys
import pickle
import ida_pro
import json
Exit = ida_pro.qexit

GetOpType = get_operand_type
GetOperandValue = get_operand_type
SegName = get_segm_name
autoWait = auto_wait
GetFunctionName = get_func_name
GetIdbPath = get_idb_path
GetInputFile = get_root_filename
GetInputFilePath = get_input_file_path

#---- prepare environment
def wait_for_analysis_to_finish():
    '''
    :return:
    '''
    print('[+] waiting for analysis to finish...')
    autoWait()
    print('[+] analysis finished')

def load_plugin_decompiler():
    '''
    load the hexray plugins
    :return: success or not
    '''
    is_ida64 = GetIdbPath().endswith(".i64")
    if not is_ida64:
        idaapi.load_plugin("hexrays")
        idaapi.load_plugin("hexarm")
    else:
        idaapi.load_plugin("hexx64")
    if not idaapi.init_hexrays_plugin():
        print('[+] decompiler plugins load failed. IDAdb: %s' % GetInputFilePath())
        idc.Exit(0)

wait_for_analysis_to_finish()
load_plugin_decompiler()

#-----------------------------------

#--------------------------
spliter = "************"
class Visitor(idaapi.ctree_visitor_t):
    #preorder traversal tree
    def __init__(self, cfunc, func_name):
        idaapi.ctree_visitor_t.__init__(self, idaapi.CV_FAST|idaapi.CV_INSNS)
        self.func_name = func_name
        self.cfunc = cfunc
        self._op_type_list =[]
        self._op_name_list =[]
        self._tree_struction_list = []
        self._id_list =[]
        self._statement_num = 0
        self._callee_set = set()
        self.root = None # root node of tree

    # Generate the sub tree
    def GenerateAST(self, ins):
        self._statement_num += 1
        AST = Tree()
        try:
            print("[insn] op  %s" % (ins.opname))
            AST.op=ins.op
            AST.opname = ins.opname
            AST.addr = ins.ea

            if ins.op == idaapi.cit_block:
                self.dump_block(ins.ea, ins.cblock, AST)
            elif ins.op == idaapi.cit_expr:
                AST.add_child(self.dump_expr(ins.cexpr))

            elif ins.op == idaapi.cit_if:
                print("[if]"+spliter)
                cif = ins.details
                cexpr = cif.expr
                ithen = cif.ithen
                ielse = cif.ielse

                AST.add_child(self.dump_expr(cexpr))
                if ithen:
                    AST.add_child(self.GenerateAST(ithen))
                if ielse:
                    AST.add_child(self.GenerateAST(ielse))

            elif ins.op == idaapi.cit_while:
                cwhile = ins.details
                self.dump_while(cwhile,AST)

            elif ins.op == idaapi.cit_return:
                creturn = ins.details
                AST.add_child( self.dump_return(creturn) )

            elif ins.op == idaapi.cit_for:
                print( '[for]'+spliter)
                cfor = ins.details
                AST.add_child(self.dump_expr(cfor.init))
                AST.add_child(self.dump_expr(cfor.step))
                AST.add_child(self.dump_expr(cfor.expr))
                AST.add_child(self.GenerateAST(cfor.body))
            elif ins.op == idaapi.cit_switch:
                print('[switch]'+spliter)
                cswitch = ins.details
                cexpr = cswitch.expr
                ccases = cswitch.cases #Switch cases: values and instructions.
                cnumber = cswitch.mvnf #Maximal switch value and number format.
                AST.add_child(self.dump_expr(cexpr))
                self.dump_ccases(ccases, AST)
            elif ins.op == idaapi.cit_do:
                print('[do]'+spliter)
                cdo = ins.details
                cbody = cdo.body
                cwhile = cdo.expr
                AST.add_child(self.GenerateAST(cbody))
                AST.add_child(self.dump_expr(cwhile))
            elif ins.op == idaapi.cit_break or ins.op == idaapi.cit_continue:
                pass
            elif ins.op == idaapi.cit_goto:
                pass
            else:
                print('[error] not handled op type %s' % ins.opname)

        except Exception as e:
            print(e)
            print("[E] exception here ! ")

        return AST


    def visit_insn(self, ins):
        # pre-order visit ctree Generate new AST
        # ins maybe None , why ?

        if not ins:
            return 1
        # print("[AST] address and op %s %s" % (hex(ins.ea), ins.opname))
        self.root = self.GenerateAST(ins)
        print(self.root)
        return 1

    def dump_return(self, creturn):
        '''
        return an expression?
        '''
        return self.dump_expr(creturn.expr)

    def dump_while(self, cwhile, parent):
        '''
        visit while statement
        return:
            condition: expression tuple
            body : block
        '''
        expr = cwhile.expr
        parent.add_child(self.dump_expr(expr))
        whilebody = None
        body = cwhile.body
        if body:
            parent.add_child(self.GenerateAST(body))

    def dump_ccases(self, ccases, parent_node):
        '''
        :param ccases:
        :return: return a list of cases
        '''
        for ccase in ccases:
            AST = Tree()
            AST.opname = 'case'
            AST.op = ccase.op
            print('case opname %s, op %d' % (ccase.opname, ccase.op))
            value = 0 #default
            size = ccase.size() #List of case values. if empty, then 'default' case , ： 'acquire', 'append', 'disown', 'next', 'own
            if size > 0:
                value = ccase.value(0)
            AST.value = value
            block = self.dump_block(ccase.ea, ccase.cblock, AST)
            parent_node.add_child(AST)

    def dump_expr(self, cexpr):
        '''
        print the expression
        :return: AST with two nodes op and oprand : op Types.NODETYPE.OPTYPE, oprand : list[]
        '''
        # print "dumping expression %x" % (cexpr.ea)

        if not cexpr:
            print("Tree is empty ! ! ! ")
            return Tree() 
    
        oprand =[] # a list of Tree()
        print("[expr] op %s" % cexpr.opname)

        if cexpr.op == idaapi.cot_call:
            # oprand = args
            # get the function call arguments
            self._get_callee(cexpr.ea)
            print('[call]'+spliter)
            args = cexpr.a
            for arg in args:
                oprand.append(self.dump_expr(arg))
        elif cexpr.op == idaapi.cot_idx:
            print('[idx]'+spliter)
            oprand.append(self.dump_expr(cexpr.x))
            oprand.append(self.dump_expr(cexpr.y))

        elif cexpr.op == idaapi.cot_memptr:
            print('[memptr]'+spliter)
            #TODO
            AST=Tree()
            AST.op = idaapi.cot_num #consider the mem size pointed by memptr
            AST.value = cexpr.ptrsize
            AST.opname = "value"
            oprand.append(AST)
            # oprand.append(cexpr.m) # cexpr.m : member offset
            # oprand.append(cexpr.ptrsize)
        elif cexpr.op == idaapi.cot_memref:

            offset = Tree()
            offset.op = idaapi.cot_num
            offset.opname = "offset"
            offset.addr = cexpr.ea
            offset.value = cexpr.m
            oprand.append(offset)

        elif cexpr.op == idaapi.cot_num:
            print ('[num]' + str(cexpr.n._value))
            AST = Tree()
            AST.op = idaapi.cot_num  # consider the mem size pointed by memptr
            AST.value = cexpr.n._value
            AST.opname = "value"
            oprand.append(AST)

        elif cexpr.op == idaapi.cot_var:

            var = cexpr.v
            entry_ea = var.mba.entry_ea
            idx = var.idx
            ltree = Tree()
            ltree.op = idaapi.cot_memptr
            ltree.addr = cexpr.ea
            ltree.opname = 'entry_ea'
            ltree.value = entry_ea
            oprand.append(ltree)
            rtree = Tree()
            rtree.value = idx
            rtree.op = idaapi.cot_num
            rtree.addr = cexpr.ea
            rtree.opname = 'idx'
            oprand.append(rtree)

        elif cexpr.op == idaapi.cot_str:
            # string constant
            print( '[str]' + cexpr.string)
            AST =Tree()
            AST.opname = "string"
            AST.op = cexpr.op
            AST.value = cexpr.string
            oprand.append(AST)

        elif cexpr.op == idaapi.cot_obj:
            print ('[cot_obj]' + hex(cexpr.obj_ea))
            # oprand.append(cexpr.obj_ea)
            # Many strings are defined as 'obj'
            # I wonder if 'obj' still points to other types of data?
            # notice that the address of 'obj' is not in .text segment
            if get_segm_name(getseg(cexpr.obj_ea)) not in ['.text']:
                AST = Tree()
                AST.opname = "string"
                AST.op = cexpr.op
                string_content = idc.get_strlit_contents(cexpr.obj_ea, -1, idc.STRTYPE_C)
                if string_content:
                    AST.value = string_content.decode('utf-8', errors='ignore')  # 转为可读字符串
                else:
                    AST.value = f"<invalid_string@{cexpr.obj_ea:x}>" 
                print(f"AST.value: {AST.value}")
                oprand.append(AST)

        elif cexpr.op <= idaapi.cot_fdiv and cexpr.op >= idaapi.cot_comma:
            #All binocular operators
            oprand.append(self.dump_expr(cexpr.x))
            oprand.append(self.dump_expr(cexpr.y))

        elif cexpr.op >= idaapi.cot_fneg and cexpr.op <= idaapi.cot_call:
            # All unary operators
            print( '[single]' + spliter)
            oprand.append(self.dump_expr(cexpr.x))
        else:
            print ('[error] %s not handled ' % cexpr.opname)
        AST = Tree()
        AST.opname=cexpr.opname
        AST.op=cexpr.op
        for tree in oprand:
            AST.add_child(tree)
        return AST

    def dump_block(self, ea, b, parent):
        '''
        :param ea: block address
        :param b:  block_structure
        :param parent: parent node
        :return:
        '''
        # iterate over all block instructions
        for ins in b:
            if ins:
                parent.add_child(self.GenerateAST(ins))

    def get_pseudocode(self):
        sv = self.cfunc.get_pseudocode()
        code_lines = []
        found_func_declaration = False
        if self.func_name.startswith("_"):
            s_func_name = self.func_name[1:]  
        else:
            s_func_name = self.func_name  
    
        for sline in sv:
            line = tag_remove(sline.line)

            if not found_func_declaration and s_func_name in line:             
                line = line.replace(s_func_name, 'func_name')
                found_func_declaration = True
              
            code_lines.append(line)
        return "\n".join(code_lines)

    def get_caller(self):
        call_addrs = list(idautils.CodeRefsTo(self.cfunc.entry_ea, 0))
        return len(set(call_addrs))

    def get_callee(self):
        return len(self._callee_set)

    def _get_callee(self, ea):
        '''
        :param ea:  where the call instruction points to
        :return: None
        '''
        print('analyse addr %s callee' % hex(ea))
        addrs = list(idautils.CodeRefsFrom(ea,0))
        for addr in addrs:
            if addr != idaapi.BADADDR:  # 检查有效地址
                func_ea = GetFunctionAttr(addr, FUNCATTR_START)
                if func_ea != idaapi.BADADDR:
                    self._callee_set.add(func_ea)
            else:
                print("Addr is valid !")

class Tree(object):
    def __init__(self):
        self.parent = None
        self.num_children = 0
        self.children = list()
        self.op = None #
        self.value = None #
        self.opname = "" #
        self.addr = None  # 添加地址信息

    def add_child(self, child):
        child.parent = self
        self.num_children += 1
        self.children.append(child)

    def to_dict(self):
        """将树转换为字典形式，便于输出和序列化"""
        return {
            # 'op': self.op,
            'opname': self.opname,
            # 'value': self.value,
            # 'addr': self.addr,
            'children': [child.to_dict() for child in self.children]
        }
    
    def size(self):
        try:
            if getattr(self, '_size'):
                return self._size
        except AttributeError as e:
            count = 1
            for i in range(self.num_children):
                count += self.children[i].size()
            self._size = count
            return self._size

    def depth(self):
        if getattr(self, '_depth'):
            return self._depth
        count = 0
        if self.num_children > 0:
            for i in range(self.num_children):
                child_depth = self.children[i].depth()
                if child_depth > count:
                    count = child_depth
            count += 1
        self._depth = count
        return self._depth
    
    def _to_string(self, indent):
        """递归生成树结构的字符串表示"""
        result = "  " * indent + f"{self.opname}"
        if self.value is not None:
            result += f" (value: {self.value})"
        if self.addr is not None:
            result += f" @{hex(self.addr)}"
        result += "\n"
        for child in self.children:
            result += child._to_string(indent + 1)
        return result
    
    def __str__(self):
        return self._to_string(0)
  
class AstGenerator():

    def __init__(self, optimization_level = "default", compiler = 'gcc'):
        '''
        :param optimization_level: the level of optimization when compile
        :param compiler: the compiler name like gcc
        '''
        if optimization_level not in ["O0","O1","O2","O3","Os","default"]:
            print("No specific optimization level !!!")
        self.optimization_level =optimization_level
        self.bin_file_path = GetInputFilePath() # path to binary
        self.file_name = GetInputFile() # name of binary
        # get process info
        self.bits, self.arch, self.endian = self._get_process_info()
        self.function_info_list = list()
        #Save the information of all functions, of which ast class is saved using pick.dump.
        # Each function is saved with a tuple (func_name. func_addr, ast_pick_dump, pseudocode, callee, caller)

    def _get_process_info(self):
        # Get processor info
        import ida_idp
        import ida_ida
        
        # Get bitness (32/64)
        bitness = 64 if ida_ida.inf_is_64bit() else 32 
        
        # Get processor name
        proc_name = ida_idp.get_idp_name()
        
        # Get endianness
        endian = 'little' if ida_ida.inf_is_be() == 0 else 'big'
        print(f"bitness: {bitness}, proc_name: {proc_name}, endian: {endian}")
        return bitness, proc_name, endian
   
    def progreeBar(self, i):
        sys.stdout.write('\r%d%% [%s]' %(int(i), "#"*i))
        sys.stdout.flush()

    def run(self, fn, specical_name = ""):
        '''
        :param fn: a function to handle the functions in binary
        :param specical_name: specific function name while other functions are ignored
        :return:
        '''
        if specical_name!="":
            print("specific functino name %s" % specical_name)
        for i in range(0, get_func_qty()):
            func = getn_func(i)
            self.progreeBar(int((i*1.0)/get_func_qty()*100))
            segname = get_segm_name(getseg(func.start_ea))
            if segname[1:3] not in ["OA", "OM", "te", "_t"]:
                continue
            func_name = GetFunctionName(func.start_ea)
            if len(specical_name) > 0 and specical_name != func_name:
                continue
            try:
                ast_tree, pseudocode, callee_num, caller_num = fn(func, func_name)
                print("AST_TREE:"+str(type(ast_tree)))
                self.function_info_list.append((func_name, func.start_ea, pickle.dumps(ast_tree), pseudocode))
            except Exception as e:
                print("%s error" % fn)
                print(str(e))

    def save_to(self):
        print("%s records to be saved" % len(self.function_info_list))
        base_dir = os.path.join(txt_root, self.bin_file_path.replace('/', '-'))
        code_dir = os.path.join(c_code_root, self.bin_file_path.replace('/', '-'))
        asm_dir = os.path.join(asm_code_root, self.bin_file_path.replace('/', '-'))  # 汇编代码目录
        os.makedirs(base_dir, exist_ok=True)
        os.makedirs(code_dir, exist_ok=True)
        os.makedirs(asm_dir, exist_ok=True)  # 创建汇编代码目录

        for info in self.function_info_list:
            try:
                function_name = info[0]
                func_addr = info[1]
                ast_info = pickle.loads(info[2])
                pseudocode = info[3]
                        
                # 保存AST为JSON
                json_path = os.path.join(base_dir, f"{function_name}.json")
                if not os.path.exists(json_path):
                    with open(json_path, 'w') as jf:
                        json.dump(ast_info.to_dict(), jf, indent=2)
                    print(f"Saved AST for {function_name}")
                
                # 保存伪代码
                c_code_path = os.path.join(code_dir, f"{function_name}.c")
                if not os.path.exists(c_code_path):
                    with open(c_code_path, 'w') as f:
                        f.write(pseudocode)
                    print(f"Saved pseudocode for {function_name}")    
                
                # 新增：保存汇编代码
                asm_path = os.path.join(asm_dir, f"{function_name}")
                if not os.path.exists(asm_path):
                    with open(asm_path, 'w') as af:
                        # 获取函数的汇编代码
                        asm_lines = self.get_assembly_code(func_addr)
                        af.write("\n".join(asm_lines))
                    print(f"Saved assembly code for {function_name}")
                    
            except Exception as e:
                print(f"Error saving AST for {self.bin_file_path} function {info[0]}: {str(e)}")
    
    def get_assembly_code(self, func_addr):
        """
        获取函数的汇编代码
        :param func_addr: 函数起始地址
        :return: 汇编代码列表
        """
        asm_lines = []
        func = idaapi.get_func(func_addr)
        if func:
            # 遍历函数中的所有指令
            for ea in idautils.FuncItems(func.start_ea):
                disasm = idc.generate_disasm_line(ea, 0)
                asm_lines.append(f"{hex(ea)}: {disasm}")
        return asm_lines
    
    @staticmethod
    def get_info_of_func(func, func_name):
        '''
        :param func:
        :return:
        '''
        try:
            cfunc = idaapi.decompile(func.start_ea)
            vis = Visitor(cfunc, func_name)
            vis.apply_to(cfunc.body, None)
            return vis.root, vis.get_pseudocode(), vis.get_callee(), vis.get_caller()
        except:
            print("Function %s decompilation failed" % (GetFunctionName(func.start_ea)))
            raise


if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("-o","--optimization", default="default", help="optimization level when compilation")
    ap.add_argument("-f","--function", default="", help="extract the specific function info")
    ap.add_argument("-g","--compiler", default="gcc", help="compiler name adopted during compilation")
    args = ap.parse_args(idc.ARGV[1:])
    astg = AstGenerator(args.optimization, compiler=args.compiler)
    astg.run(astg.get_info_of_func, specical_name=args.function)
    astg.save_to()
    Exit(0)





  
class AstGenerator():

    def __init__(self, optimization_level = "default", compiler = 'gcc'):
        '''
        :param optimization_level: the level of optimization when compile
        :param compiler: the compiler name like gcc
        '''
        if optimization_level not in ["O0","O1","O2","O3","Os","default"]:
            print("No specific optimization level !!!")
        self.optimization_level =optimization_level
        self.bin_file_path = GetInputFilePath() # path to binary
        self.file_name = GetInputFile() # name of binary
        # get process info
        self.bits, self.arch, self.endian = self._get_process_info()
        self.function_info_list = list()
        #Save the information of all functions, of which ast class is saved using pick.dump.
        # Each function is saved with a tuple (func_name. func_addr, ast_pick_dump, pseudocode, callee, caller)

    def _get_process_info(self):
        # Get processor info
        import ida_idp
        import ida_ida
        
        # Get bitness (32/64)
        bitness = 64 if ida_ida.inf_is_64bit() else 32 
        
        # Get processor name
        proc_name = ida_idp.get_idp_name()
        
        # Get endianness
        endian = 'little' if ida_ida.inf_is_be() == 0 else 'big'
        print(f"bitness: {bitness}, proc_name: {proc_name}, endian: {endian}")
        return bitness, proc_name, endian
    

    def get_assembly_code(self, func_addr, min_lines=5):
        """
        获取函数的汇编代码
        :param func_addr: 函数起始地址
        :return: 汇编代码列表
        """
        asm_lines = []
        func = idaapi.get_func(func_addr)
        if func:
            for ea in idautils.FuncItems(func.start_ea):
                disasm = idc.generate_disasm_line(ea, 0)
                asm_lines.append(f"{hex(ea)}: {disasm}")
        return asm_lines        
            

    def progreeBar(self, i):
        sys.stdout.write('\r%d%% [%s]' %(int(i), "#"*i))
        sys.stdout.flush()

    def run(self, fn, specical_name = ""):
        '''
        :param fn: a function to handle the functions in binary
        :param specical_name: specific function name while other functions are ignored
        :return:
        '''
        if specical_name!="":
            print("specific functino name %s" % specical_name)
        for i in range(0, get_func_qty()):
            func = getn_func(i)
            self.progreeBar(int((i*1.0)/get_func_qty()*100))
            segname = get_segm_name(getseg(func.start_ea))
            if segname[1:3] not in ["OA", "OM", "te", "_t"]:
                continue
            func_name = GetFunctionName(func.start_ea)
            if len(specical_name) > 0 and specical_name != func_name:
                continue
            try:
                ast_tree, pseudocode, callee_num, caller_num = fn(func, func_name)
                print("AST_TREE:"+str(type(ast_tree)))
                self.function_info_list.append((func_name, pickle.dumps(ast_tree), pseudocode))
            except Exception as e:
                print("%s error" % fn)
                print(str(e))

    def save_to(self):
        print("%s records to be saved" % len(self.function_info_list))
        base_dir = os.path.join(txt_root, self.bin_file_path.replace('/', '-'))
        code_dir = os.path.join(c_code_root, self.bin_file_path.replace('/', '-'))
        os.makedirs(base_dir, exist_ok=True)
        os.makedirs(code_dir, exist_ok=True)

        for info in self.function_info_list:
            try:
                function_name = info[0]
                ast_info = pickle.loads(info[1])
                pseudocode = info[2]
                        
                json_path = os.path.join(base_dir, f"{function_name}.json")

                if not os.path.exists(json_path):
                    with open(json_path, 'w') as jf:
                        json.dump(ast_info.to_dict(), jf, indent=2)
                    print(f"Saved AST for {function_name}")
                
                c_code_path = os.path.join(code_dir, f"{function_name}.c")
                if not os.path.exists(c_code_path):
                    with open(c_code_path, 'w') as f:
                        f.write(pseudocode)
                    print(f"Saved pseudocode for {function_name}")    
            except Exception as e:
                print(f"Error saving AST for {self.bin_file_path} function {info[0]}: {str(e)}")
    
    @staticmethod
    def get_info_of_func(func, func_name):
        '''
        :param func:
        :return:
        '''
        try:
            cfunc = idaapi.decompile(func.start_ea)
            vis = Visitor(cfunc, func_name)
            vis.apply_to(cfunc.body, None)
            return vis.root, vis.get_pseudocode(), vis.get_callee(), vis.get_caller()
        except:
            print("Function %s decompilation failed" % (GetFunctionName(func.start_ea)))
            raise


if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("-o","--optimization", default="default", help="optimization level when compilation")
    ap.add_argument("-f","--function", default="", help="extract the specific function info")
    ap.add_argument("-g","--compiler", default="gcc", help="compiler name adopted during compilation")
    args = ap.parse_args(idc.ARGV[1:])
    astg = AstGenerator(args.optimization, compiler=args.compiler)
    astg.run(astg.get_info_of_func, specical_name=args.function)
    # astg = AstGenerator("O0", compiler="gcc")  # this line code for test
    # astg.run(astg.get_info_of_func, specical_name="") # this line code for test
    astg.save_to()
    Exit(0)