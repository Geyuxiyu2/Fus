"""
生成训练数据集的AST
"""
import os
import csv
from generate import extract_function_ast

base_dir = "/data/LYL/lyl_bcsd/dataset/eval/AST"
csv_path = "/home/liyanlin/HLS/graph/csv/cross_opt_balanced_20000_same_arch.csv"

# 架构文件夹
arch_folders = ["arm-32", "arm-64", "mips-32", "mips-64", "x86-32", "x86-64"]


def get_ast(binary, func=""):
    """获取或生成指定二进制函数的AST"""
    dir_path = os.path.join(base_dir, binary.replace('/', '-'))
    # if not os.path.exists(dir_path):
    #     extract_function_ast(binary, func="")
    
    json_path = os.path.join(dir_path, f"{func}.json")
    if not os.path.exists(json_path):
        extract_function_ast(binary)
        

def process_csv(csv_file):
    """处理CSV文件，提取所有函数的AST"""
    with open(csv_file, 'r') as f:
        reader = csv.reader(f)
        
        for row in reader:
            if len(row) < 5:  # 确保每行有足够的数据
                continue
                
            binary1, func1, binary2, func2, label = row
            # print(f"Processing: {binary1}:{func1} vs {binary2}:{func2}")
            
            # 处理第一个二进制文件的函数
            try:
                get_ast(binary1, func1)
            except Exception as e:
                print(f"Error processing {binary1} {func1}: {str(e)}")
            
            # 处理第二个二进制文件的函数
            try:
                get_ast(binary2, func2)
            except Exception as e:
                print(f"Error processing {binary2} {func2}: {str(e)}")

if __name__ == "__main__":
    # 确保基础目录存在
    if not os.path.exists(base_dir):
        os.makedirs(base_dir)
    
    # 处理CSV文件中的所有函数对
    process_csv(csv_path)
    print("AST extraction completed.")