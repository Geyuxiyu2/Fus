import sys
sys.path.append('/home/liyanlin/HLS/baseline')
import os
import random
import csv
import pandas as pd
from collections import defaultdict
from generate import extract_function_ast
from tqdm import tqdm
import torch, json, r2pipe, pprint, os, tqdm, pickle, glob, time
from difflib import SequenceMatcher
import pandas as pd
from concurrent.futures import ThreadPoolExecutor, as_completed
import multiprocessing
import threading

from SAFEtorch.utils.capstone_disassembler import disassemble
from SAFEtorch.utils.radare_analyzer import BinaryAnalyzer

import torch
import sys, os, time, tqdm, pickle
from difflib import SequenceMatcher

cache_lock = threading.Lock()

output_dir = "/home/liyanlin/HLS/graph/csv/output-ida-2"
cache_dir = "/data/LYL/lyl_bcsd/dataset/eval/cache"

os.makedirs(output_dir, exist_ok=True)
os.makedirs(cache_dir, exist_ok=True)

def get_cache_path(bin_path):
    """根据二进制文件路径生成缓存文件路径"""
    # 替换路径中的斜杠为破折号，并确保文件名合法
    safe_bin_path = bin_path.replace('/', '-')
    return os.path.join(cache_dir, f"{safe_bin_path}.pkl")

def get_cached_functions(bin_path):
    """获取缓存的函数列表"""
    cache_file = get_cache_path(bin_path)
    with cache_lock: 
        if os.path.exists(cache_file):
            try:
                with open(cache_file, 'rb') as f:
                    return pickle.load(f)
            except Exception as e:
                # 如果缓存文件损坏，删除并返回None
                print(e)
                try:
                    os.remove(cache_file)
                except FileNotFoundError:
                    pass  # 文件已被其他线程删除
                return None
    return None

def cache_functions(bin_path, functions):
    """缓存函数列表"""
    cache_file = get_cache_path(bin_path)
    
    # 确保缓存目录存在
    os.makedirs(os.path.dirname(cache_file), exist_ok=True)
    
    with open(cache_file, 'wb') as f:
        pickle.dump(functions, f)

def similarity(a, b):
    return SequenceMatcher(None, a, b).ratio()

def r2_func_rename(bin_path, func):
    # 首先尝试从缓存获取函数列表
    cached_functions = get_cached_functions(bin_path)
    # print(f"cached_functions:{cached_functions}")
    func_list = []
    if cached_functions is not None:
        for f in cached_functions:
            func_r = f['name'].replace("sym.", "").replace("dbg.", "")
            if func_r == func:
                func_list.append(f['name']) 
        return func_list

    else:
        # 没有缓存，执行分析
        print(f"===开始分析 {bin_path}, {func} ===")
        r2obj = r2pipe.open(bin_path, flags=["-2"])
        r2obj.cmd('aaaa')
        functions = r2obj.cmdj("aflj")
        # 缓存结果
        cache_functions(bin_path, functions)
        r2obj.quit()

        for f in functions:
            func_r = f['name'].replace("sym.", "").replace("dbg.", "")
            if func_r == func:
                func_list.append(f['name']) 
        return func_list

def check_radare(bin_path, func_r):
    flag = True
    base_name = bin_path.replace('/','-')
    json_path = os.path.join('/data/LYL/lyl_bcsd/dataset/eval/baseline/GMN/', base_name, f"{func_r}.json") 
    # print(json_path)
    if os.path.exists(json_path):   
        # print("已存在")
        return flag
    
    r2 = r2pipe.open(bin_path, flags=["-2"])
    r2.cmd('aaaa')
    r2.cmd('s '+func_r)
    agfj = r2.cmdj('agfj ')
    if not agfj:
        flag = False
    return flag

def check_safe(bin_path, func_r):
    binary = BinaryAnalyzer(bin_path)
    offsets = binary.get_functions()
    for func in offsets:
        if func[1] != func_r:
            continue
        best_match = func
        asm = binary.get_hexasm(best_match[0])
        instructions = disassemble(asm, binary.arch, binary.bits)
        if instructions == []:
            return False
        
    return True
            

skip_suffixes = {'i64', 'id0', 'id1', 'id2', 'nam', 'til'}

class BinaryDatasetGenerator:
    def __init__(self, dataset_dir, ast_base_dir, asm_code_root, c_code_dir, output_dir):
        self.dataset_dir = dataset_dir
        self.output_dir = output_dir
        self.ast_base_dir = ast_base_dir
        self.asm_code_root = asm_code_root
        self.c_code_dir = c_code_dir
        self.binary_cache = {}
        self.pair_types = {
            "XA": lambda b1, b2: (b1['compiler'] == b2['compiler'] and 
                                 b1['arch2'] != b2['arch2'] and 
                                 b1['opt'] == b2['opt']),
            "XO": lambda b1, b2: (b1['compiler'] == b2['compiler'] and 
                                 b1['arch'] == b2['arch'] and 
                                 b1['opt'] != b2['opt']),
            "XC": lambda b1, b2: (b1['compiler'] != b2['compiler'] and 
                                 b1['arch'] == b2['arch'] and 
                                 b1['opt'] == b2['opt']),
            "XA+XC": lambda b1, b2: (b1['arch2'] != b2['arch2'] and 
                                   b1['compiler'] != b2['compiler'] and 
                                   b1['opt'] == b2['opt']),
            "XA+XO": lambda b1, b2: (b1['compiler'] == b2['compiler'] and 
                                   b1['arch2'] != b2['arch2'] and 
                                   b1['opt'] != b2['opt']),
            "XO+XC": lambda b1, b2: (b1['compiler'] != b2['compiler'] and 
                                   b1['arch'] == b2['arch'] and 
                                   b1['opt'] != b2['opt']),
            "XA+XO+XC": lambda b1, b2: (b1['compiler'] != b2['compiler'] and 
                                    b1['arch2'] != b2['arch2'] and 
                                    b1['opt'] != b2['opt'])
        }
    
    def check_existing_data(self):
        """Check for existing CSV files and return counts and used pairs"""
        type_counts = {pair_type: 0 for pair_type in self.pair_types}
        used_pairs = set()
        used_project_funcs_per_category = {
            pair_type: set() for pair_type in self.pair_types
        }

        for pair_type in self.pair_types:
            csv_file = os.path.join(self.output_dir, f"{pair_type}.csv")
            if os.path.exists(csv_file):
                try:
                    # Read existing CSV file
                    df = pd.read_csv(csv_file, header=None)
                    if not df.empty:
                        # Update counts
                        type_counts[pair_type] = len(df)
                        
                        # Update used pairs
                        for _, row in df.iterrows():
                            bin1_path, func1, bin2_path, func2, _ = row
                            pair_key = frozenset({bin1_path, bin2_path})
                            used_pairs.add(pair_key)
                            
                            # Update used project-func pairs
                            bin1 = self.get_project_info(bin1_path)
                            if bin1:
                                project = bin1['project']
                                project_func_id = (project, func1)
                                used_project_funcs_per_category[pair_type].add(project_func_id)
                except Exception as e:
                    print(f"Error reading {csv_file}: {e}")
                    continue

        return type_counts, used_pairs, used_project_funcs_per_category
    
    def get_project_info(self, binary_path):
        """Extract project info from binary path"""
        basename = os.path.basename(binary_path)
        
        if "ase18_debug" in binary_path:
            dirname = os.path.basename(os.path.dirname(binary_path))
            mbdirname = dirname.replace('_', '.')
            basename = basename.replace(f"-{(dirname)}_", f"-{mbdirname}_")
        
        parts = basename.split('_')
        
        if len(parts) >= 6:
            project = parts[0]
            compiler = parts[1]
            arch = '_'.join(parts[2:4])
            if parts[2] == "mipseb":
                parts[2] = "mips"
            arch2 = '_'.join(parts[2:4])
            opt = parts[4]
            # print(f"project: {project}, compiler:{compiler}, arch:{arch}, arch2:{arch2}, opt:{opt}, path:{binary_path}")
            return {
                'project': project,
                'compiler': compiler,
                'arch': arch,
                'arch2': arch2,
                'opt': opt,
                'path': binary_path
            }
        return None
    
    def classify_pair(self, bin1, bin2):
        """Classify a binary pair into all matching categories"""
        for pair_type, condition in self.pair_types.items():
            if condition(bin1, bin2):
                return (pair_type)
        return None
    
    def get_binary_functions(self, binary_path):
        """Get function list for a binary from AST directory"""
        binary_identifier = binary_path.replace('/', '-')
        binary_dir = os.path.join(self.ast_base_dir, binary_identifier)
        asm_dir = os.path.join(self.asm_code_root, binary_identifier)
        code_dir = os.path.join(self.c_code_dir, binary_identifier)
        
        if not os.path.exists(binary_dir) or not os.path.exists(asm_dir) or not os.path.exists(code_dir):
            extract_function_ast(binary_path)
        
        try:
            functions = [f.split('.')[0] for f in os.listdir(binary_dir) if f.endswith('.json')]
            return functions
        except Exception as e:
            print(f"\nError getting functions for {binary_path}: {e}\n")
            return []
    
    def collect_binaries(self):
        """Collect all binaries grouped by project"""
        projects = defaultdict(list)
        print("Collecting binaries...")
        
        for project_dir in os.listdir(self.dataset_dir):
            project_path = os.path.join(self.dataset_dir, project_dir)
            if os.path.isdir(project_path):
                for binary_file in os.listdir(project_path):
                    if any(binary_file.endswith(suffix) for suffix in skip_suffixes):
                        continue
                    binary_path = os.path.join(project_path, binary_file)
                    projects[project_dir].append(binary_path)
        
        additional_dirs = [
            "/data/LYL/lyl_bcsd/dataset/binkit/ase18_debug/busybox_debug/1_21_stable/",
            "/data/LYL/lyl_bcsd/dataset/binkit/ase18_debug/coreutils_debug/6.5/",
            "/data/LYL/lyl_bcsd/dataset/binkit/ase18_debug/openssl_debug/OpenSSL_1_0_1f/"
        ]
        
        for add_dir in additional_dirs:
            project_name = os.path.basename(os.path.dirname(add_dir))
            if os.path.exists(add_dir):
                for binary_file in os.listdir(add_dir):
                    if any(binary_file.endswith(suffix) for suffix in skip_suffixes):
                        continue
                    binary_path = os.path.join(add_dir, binary_file)
                    projects[project_name].append(binary_path)
        

        print("Finished collecting binaries.")
        return dict(projects)
    
    def save_batch(self, datasets, output_dir, batch_num):
        """Save current batches to CSV files, appending to existing files"""
        for pair_type, pairs in datasets.items():
            if pairs:
                output_file = os.path.join(output_dir, f"{pair_type}.csv")
                df = pd.DataFrame(pairs)
                
                if not os.path.exists(output_file):
                    write_mode = 'w'
                else:
                    write_mode = 'a'
                
                df.to_csv(output_file, mode=write_mode, header=None, index=False)
                datasets[pair_type] = []
    
    def check_asm_lines(self, bin1_path, bin2_path, func_name, min_lines=4):
        
        binary_identifier1 = bin1_path.replace('/', '-')
        asm_path_func1 = os.path.join(self.asm_code_root, binary_identifier1, func_name)
        
        binary_identifier2 = bin2_path.replace('/', '-')
        asm_path_func2 = os.path.join(self.asm_code_root, binary_identifier2, func_name)

        try:
            with open(asm_path_func1, 'r') as f1:
                lines1 = f1.readlines()
                if len(lines1) <= min_lines:
                    return False
        except Exception as e:
            print(f"Error asm check {e}. func: {func_name}")
            return False

        try:
            with open(asm_path_func2, 'r') as f2:
                lines2 = f2.readlines()
                if len(lines2) <= min_lines:
                    return False
        except Exception as e:
            print(f"Error asm check {e}. func: {func_name}")
            return False

        return True
    
    def check_code_lines(self, bin1_path, bin2_path, func_name, min_lines=4):
        binary_identifier1 = bin1_path.replace('/', '-')
        code_path_func1 = os.path.join(self.c_code_dir, binary_identifier1, f"{func_name}.c")
        
        binary_identifier2 = bin2_path.replace('/', '-')
        code_path_func2 = os.path.join(self.c_code_dir, binary_identifier2, f"{func_name}.c")

        try:
            with open(code_path_func1, 'r') as f1:
                lines1 = f1.readlines()
                if len(lines1) <= min_lines:
                    return False
        except Exception as e:
            print(f"Error code check {e}. func: {func_name}")
            return False

        try:
            with open(code_path_func2, 'r') as f2:
                lines2 = f2.readlines()
                if len(lines2) <= min_lines:
                    return False
        except Exception as e:
            print(f"Error code check {e}. func: {func_name}")
            return False

        return True

    def generate_datasets(self, num_samples_per_type=10000, max_pairs_per_binary=70, batch_size=100):
        """Generate datasets for all pair types following the specified logic"""
        print("Generating datasets...")
        
        # Check for existing data and initialize counters
        type_counts, used_pairs, used_project_funcs_per_category = self.check_existing_data()
        
        # Initialize datasets
        datasets = {pair_type: [] for pair_type in self.pair_types}
        batch_num = 0
        
        # Collect all projects and their binaries
        projects = self.collect_binaries()
        
        # Create progress bar starting from current counts
        total_needed = num_samples_per_type * len(self.pair_types) - sum(type_counts.values())
        pbar = tqdm.tqdm(total=total_needed, desc="Generating dataset pairs", unit="pair")
        
        ii = 0
        # Continue until we have enough samples for all types
        while not all(count >= num_samples_per_type for count in type_counts.values()):
            pbar.set_description(f"Generating pairs (batch {batch_num})")
            ii += 1
            print(f"\n正在尝试第{ii}次")
            # 1. Randomly select a project
            project = random.choice(list(projects.keys()))
            binaries = projects[project]
            
            if len(binaries) < 2:
                continue
                
            # 2. Randomly select two different binaries from this project
            bin1_path, bin2_path = random.sample(binaries, 2)
            pair_key = frozenset({bin1_path, bin2_path})
        
            if pair_key in used_pairs:
                continue
            
            used_pairs.add(pair_key)

            # Get binary info
            bin1 = self.get_project_info(bin1_path)
            bin2 = self.get_project_info(bin2_path)
            
            if not bin1 or not bin2:
                continue
                
            # 3. Classify the pair
            category = self.classify_pair(bin1, bin2)
            if not category:
                continue
                
            if type_counts[category] >= num_samples_per_type:
                continue
                
            # 4. Get function lists for both binaries
            bin1['functions'] = self.get_binary_functions(bin1_path)
            bin2['functions'] = self.get_binary_functions(bin2_path)
            
            if not bin1['functions'] or not bin2['functions']:
                continue
                
            # 5. Find common functions
            common_funcs = list(set(bin1['functions']) & set(bin2['functions']))
            if not common_funcs:
                continue
                
            # random.shuffle(common_funcs)
            # num_to_sample = min(len(common_funcs), max_pairs_per_binary)

            # 7. Add pairs to all matching categories that still need samples
            for func in common_funcs:
                project_func_id = (project, func)
                
                if project_func_id in used_project_funcs_per_category[category]:
                    print("已存在")
                    continue  
                

                if not self.check_asm_lines(bin1_path, bin2_path, func):
                    continue
                
                if not self.check_code_lines(bin1_path, bin2_path, func):
                    continue
                
                r2_func_1_list = r2_func_rename(bin1_path, func)
                r2_func_2_list = r2_func_rename(bin2_path, func)

                if not r2_func_1_list or not r2_func_2_list:
                    continue
                
                intersection = set(r2_func_1_list) & set(r2_func_2_list)
                intersection = list(intersection)

                if not intersection:
                    continue

                if intersection:
                    dbg_names = [name for name in intersection if name.startswith("dbg.")]
                if dbg_names:
                    selected_name = dbg_names[0]
                else:
                    selected_name = intersection[0]   

                flag1 = check_radare(bin1_path, selected_name)
                flag2 = check_radare(bin2_path, selected_name)  

                if not flag1 or not flag2:  
                    continue
                
                flag_safe_1 = check_safe(bin1_path, selected_name)
                flag_safe_2 = check_safe(bin2_path, selected_name)

                if not flag_safe_1 or not flag_safe_2:  
                    continue

                if type_counts[category] < num_samples_per_type:                      
                    used_project_funcs_per_category[category].add(project_func_id)                      
                    datasets[category].append({
                        'binary1': bin1_path,
                        'func1': func,
                        'binary2': bin2_path,
                        'func2': func,
                        'label': 1
                    })
                    type_counts[category] += 1
                    pbar.update(1)
                        
                    # if type_counts[category] % batch_size == 0:
                    #     self.save_batch(datasets, self.output_dir, batch_num)
                    #     type_counts, used_pairs, used_project_funcs_per_category = self.check_existing_data()
                    #     batch_num += 1
                    
                    if all(count >= num_samples_per_type for count in type_counts.values()):
                        break
                else:
                    continue
    
            pbar.set_postfix({k: v for k, v in type_counts.items()})
            
        if any(pairs for pairs in datasets.values()):
            self.save_batch(datasets, self.output_dir, batch_num)
        
        pbar.close()
        print("Finished generating datasets.")
        return type_counts

def main():
    dataset_dir = "/data/LYL/lyl_bcsd/dataset/binkit/gnu_debug/"
    ast_base_dir = "/data/LYL/lyl_bcsd/dataset/eval/AST"
    c_code_root="/data/LYL/lyl_bcsd/dataset/eval/c_code"
    asm_code_root="/data/LYL/lyl_bcsd/dataset/eval/asm_code" 
    output_dir = "/home/liyanlin/HLS/graph/csv/output-ida-2/"
    
    os.makedirs(output_dir, exist_ok=True)
    
    generator = BinaryDatasetGenerator(dataset_dir, ast_base_dir, asm_code_root, c_code_root, output_dir)
    # generator.get_project_info("/data/LYL/lyl_bcsd/dataset/binkit/ase18_debug/busybox_debug/1_21_stable/busybox-1_21_stable_clang-4.0_arm_32_O0_busybox_unstripped.elf")
    print("Generating all datasets simultaneously...")
    counts = generator.generate_datasets()
    
    # counts_file = os.path.join(output_dir, "final_counts.txt")
    # with open(counts_file, 'w') as f:
    #     f.write("Final counts:\n")
    #     for pair_type, count in counts.items():
    #         f.write(f"{pair_type}: {count} pairs\n")

if __name__ == "__main__":
    main()